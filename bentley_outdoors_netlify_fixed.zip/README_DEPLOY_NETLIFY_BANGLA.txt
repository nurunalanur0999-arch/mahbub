BENTLEY OUTDOORS — GITHUB + NETLIFY DEPLOYMENT
================================================

This is a static multi-page website. No Node.js build step or backend is required.

PAGES
- index.html        Home
- about.html        About
- services.html     Services
- projects.html     Projects
- service-areas.html Service Areas
- process.html      Process
- contact.html      Contact / Get a Quote

STEP 1 — CREATE A GITHUB REPOSITORY
1. Go to https://github.com/new and sign in.
2. Repository name: bentley-outdoors-website
3. Choose Public or Private (either works with Netlify).
4. Click Create repository.
5. Upload the CONTENTS of this folder to the repository root. Important: index.html,
   netlify.toml, styles.css, site.js, data.js, assets.js, and the assets folder must
   appear at the repository's top level; do not upload a parent folder containing them.
6. Commit the files to the main branch.

STEP 2 — CONNECT GITHUB TO NETLIFY
1. Go to https://app.netlify.com/ and sign in.
2. Choose Add new project / Add new site, then Import an existing project.
3. Select GitHub and authorize Netlify if asked.
4. Select the bentley-outdoors-website repository.
5. Build settings:
   - Base directory: leave blank
   - Build command: leave blank (no build command needed)
   - Publish directory: .
   The included netlify.toml already sets publish = ".".
6. Click Deploy site.
7. When deploy finishes, open the generated *.netlify.app URL.

STEP 3 — FUTURE UPDATES
Edit the files in GitHub and commit changes. Netlify will automatically redeploy
when the connected branch receives a new commit.

IMPORTANT BEFORE PUBLISHING
- Verify business phone, email, service area, opening hours, and any certification claims.
- Portfolio imagery is illustrative unless confirmed as real completed client work.
- The inquiry form prepares a message and opens email/WhatsApp links; it does not save
  submissions to a database or send them to a server automatically.
- Before & After section has been removed.
- No public live URL has been created by this package itself; the GitHub/Netlify steps above
  are required to publish it.
